'''Trains SemiSupervised-DCGAN on num_classes classes dataset using tf2/Keras

Inspired by original source code from [1]
we add Semi-supervised Mechanism according to Ref.[3] 
@ mikelu-shanghai

DCGAN is a Generative Adversarial Network (GAN) using CNN.
The generator tries to fool the discriminator by generating fake images.
The discriminator learns to discriminate real from fake images.
The generator + discriminator form an adversarial network.
DCGAN trains the discriminator and adversarial networks alternately.
During training, not only the discriminator learns to distinguish real from
fake images & which class, it also coaches the generator part of the adversarial 
on how to improve its ability to generate fake images.

[1] Rowel Atienza. "Advanced Deep Learning with TensorFlow 2 and Keras(2nd
Edition)". Packt Publishing, BIRMINGHAM - MUMBAI, 2020.
[2] Radford, Alec, Luke Metz, and Soumith Chintala.
"Unsupervised representation learning with deep convolutional
generative adversarial networks." arXiv preprint arXiv:1511.06434 (2015).
[3] Jakub Langr, Vladimir Bok. "GANs in Action-Deep Learing with Generative
Adversarial Networks". Manning, Shelter Island, 2019. pp.123.
'''


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from numpy.core.fromnumeric import argmax

from tensorflow.keras.layers import Activation, Dense, Input, Lambda
from tensorflow.keras.layers import Conv2D, Flatten, GlobalAveragePooling2D
from tensorflow.keras.layers import Reshape, Conv2DTranspose, concatenate
from tensorflow.keras.layers import BatchNormalization, Dropout, LeakyReLU
from tensorflow.keras.optimizers import RMSprop, Adam
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.models import load_model
from tensorflow.keras import backend as K
from tensorflow.keras.utils import to_categorical

import tensorflow as tf
import numpy as np
import math
import matplotlib.pyplot as plt
import os
import argparse
import sys

sys.path.append("..")

#############################################################
#-----------------------Dataset & Load-----------------------
#############################################################

import shutil, os
import random
import cv2

#* PARAMETERS CONFIGURATION
num_labeled = 2800*2*2  # int(56092*labeled_rate/batch_size)*batch_size
batch_size = 16     # 16
image_size = 224    # 256/224
input_size_dim_1 = image_size  
input_size_dim_2 = image_size
num_classes = 2 
model_name = "SS-DCGAN_2classes_ResNet152V2"

# TODO dataset_loader.py
current_cwd = os.getcwd()

# for both windows OS and Linux OS
original_dataset_dir_CP = os.path.join(current_cwd, 'Datasets/SDNET2018_original/CP')
original_dataset_dir_UP = os.path.join(current_cwd, 'Datasets/SDNET2018_original/UP')
base_dir = os.path.join(current_cwd, 'Datasets/SDNET2018_uneven2')
os.mkdir(base_dir)

# Directories for labeled, training, validation and test splits
labeled_dir = os.path.join(base_dir, 'labeled')
os.mkdir(labeled_dir)
train_dir = os.path.join(base_dir, 'train')
os.mkdir(train_dir)
validation_dir = os.path.join(base_dir, 'validation')
os.mkdir(validation_dir)
test_dir = os.path.join(base_dir, 'test')
os.mkdir(test_dir)

# Directory with labeled crack images
labeled_crack_dir = os.path.join(labeled_dir, 'crack')
os.mkdir(labeled_crack_dir)
# Directory with labeled uncrack images
labeled_uncrack_dir = os.path.join(labeled_dir, 'uncrack')
os.mkdir(labeled_uncrack_dir)
# Directory with training crack images
train_crack_dir = os.path.join(train_dir, 'crack')
os.mkdir(train_crack_dir)
# Directory with training uncrack images
train_uncrack_dir = os.path.join(train_dir, 'uncrack')
os.mkdir(train_uncrack_dir)
# Directory with validation crack images
validation_crack_dir = os.path.join(validation_dir, 'crack')
os.mkdir(validation_crack_dir)
# Directory with validation uncrack images
validation_uncrack_dir = os.path.join(validation_dir, 'uncrack')
os.mkdir(validation_uncrack_dir)
# Directory with test crack images
test_crack_dir = os.path.join(test_dir, 'crack')
os.mkdir(test_crack_dir)
# Directory with test uncrack images
test_uncrack_dir = os.path.join(test_dir, 'uncrack')
os.mkdir(test_uncrack_dir)


# train: validation : test = 7:1:2
samples_total_CP = int((8484 * 0.01 * 100 - num_labeled/2) // batch_size) * batch_size  # total 8484(_P: 2608) images
samples_train_CP = int((samples_total_CP * 0.7) // batch_size) * batch_size
samples_val_CP = int((samples_total_CP * 0.1) // batch_size) * batch_size
samples_test_CP = int((samples_total_CP * 0.2) // batch_size) * batch_size

samples_total_UP = int((47608 * 0.01 * 100 - num_labeled/2) // batch_size) * batch_size # total 47608(_P: 21726) images
samples_train_UP = int((samples_total_UP * 0.7) // batch_size) * batch_size
samples_val_UP = int((samples_total_UP * 0.1) // batch_size) * batch_size
samples_test_UP = int((samples_total_UP * 0.2)  // batch_size) * batch_size

# Copy crack images to labeled_crack_dir, train_crack_dir, validation_crack_dir, test_crack_dir
#* and convert rgb to gray
fnames = os.listdir(original_dataset_dir_CP)
random.shuffle(fnames)

for fname in fnames[:samples_train_CP]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(train_crack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb
    
for fname in fnames[samples_train_CP:(samples_train_CP + samples_val_CP)]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(validation_crack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*

for fname in fnames[(samples_train_CP + samples_val_CP):samples_total_CP]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(test_crack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*

for fname in fnames[samples_total_CP:(samples_total_CP + int(num_labeled/2))]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(labeled_crack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*

# Copy uncrack images to labeled_uncrack_dir, train_uncrack_dir, validation_uncrack_dir, test_uncrack_dir
# and convert rgb to gray
fnames = os.listdir(original_dataset_dir_UP)
random.shuffle(fnames)

for fname in fnames[:samples_train_UP]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(train_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*

for fname in fnames[samples_train_UP:(samples_train_UP + samples_val_UP)]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(validation_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*

for fname in fnames[(samples_train_UP + samples_val_UP):samples_total_UP]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(test_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*

for fname in fnames[samples_total_UP:(samples_total_UP + int(num_labeled/2))]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(labeled_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #*
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(dst, gray_img)
    # shutil.copyfile(src, dst)                        #*


# -------------------------
#  Batch data generator
# -------------------------
from tensorflow.keras.preprocessing.image import ImageDataGenerator

labeled_datagen = ImageDataGenerator(
    rescale=1. / 255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest')

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest')

labeled_generator = labeled_datagen.flow_from_directory(
    labeled_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    color_mode='grayscale',  #* 'rgb'  
    batch_size=batch_size,
    # Since we use binary_crossentropy loss, we need binary labels
    class_mode='binary')

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    color_mode='grayscale', 
    batch_size=batch_size,
    # Since we use binary_crossentropy loss, we need binary labels
    class_mode='binary')

# Note that the test data should not be augmented!
val_datagen = ImageDataGenerator(rescale=1. / 255)
# test_datagen = ImageDataGenerator(rescale=1. / 255)

validation_generator = val_datagen.flow_from_directory(
    validation_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    color_mode='grayscale', 
    batch_size=batch_size,
    class_mode='binary')


#############################################################
#-----------------------Build Model--------------------------
#############################################################

def build_generator(inputs, image_size):
    """Build a Generator Model

    Stack of BN-ReLU-Conv2DTranpose to generate fake images
    Output activation is sigmoid instead of tanh in [2].
    Sigmoid converges easily.
    The generator can be modified to any CNN/FCN backbone
    architecture such as ResNet etc.

    Arguments:
        inputs (Layer): Input layer of the generator 
            the z-vector)
        image_size (tensor): Target size of one side
            (assuming square image)

    Returns:
        generator (Model): Generator Model
    """
    # -------------------------
    #  Version2 for -256x256
    # -------------------------
    image_resize = image_size // 16
    # network parameters 
    kernel_size = 5
    layer_filters = [512, 256, 128, 64, 1]   # [1024, 512, 256, 128, 1]

    x = Dense(image_resize * image_resize * layer_filters[0])(inputs)   # 8x8x512/1024
    x = Reshape((image_resize, image_resize, layer_filters[0]))(x)      # (-1, 8, 8, 512/1024)

    for filters in layer_filters:
        # first 4 convolution layers use strides = 2
        # the last 1 use strides = 1
        if filters > layer_filters[-1]:
            strides = 2
        else:
            strides = 1
        x = BatchNormalization()(x)
        x = LeakyReLU(alpha=0.2)(x)  # x = Activation('relu')(x)
        x = Conv2DTranspose(filters=filters,
                            kernel_size=kernel_size,
                            strides=strides,
                            padding='same')(x)

    x = Activation('sigmoid')(x)
    generator = Model(inputs, x, name='generator')
    return generator


def build_discriminator_base(inputs):                                  
    """Build a Discriminator Model

    Stack of LeakyReLU-Conv2D to discriminate real from fake.
    The network does not converge with BN so it is not used here
    unlike in [2] or original paper.
    The discriminator can be modified to any pre-trained/fine-tuned
    CNN/FCN backbone architecture such as ResNet etc.

    Arguments:
        inputs (Layer): Input layer of the discriminator (the image)

    Returns:
        discriminator_base (Model): Discriminator_base Model
    """
    ### Import pre-trained model
     
    # -------------------------
    #  ResNet152V2 for -224x224
    # ------------------------- 
    from tensorflow.keras.applications import ResNet152V2
    weights_path_Resnet = os.path.join(current_cwd, 'PretrainedWeights/resnet152v2_weights_tf_dim_ordering_tf_kernels_notop.h5')
                         # mobilenet_1_0_224_tf_no_top.h5   inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5
    model = Sequential()
    conv_base = ResNet152V2(weights='imagenet',  # weights_path_Resnet,
                      include_top=False,
                      input_shape=None, 
                      input_tensor=inputs,
                      pooling=None,
                      classes=1000)
    
    conv_base.summary
    conv_base.trainable = False

    model.add(conv_base)
    model.add(GlobalAveragePooling2D())
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(num_classes))

    # model.add(conv_base)
    # model.add(GlobalAveragePooling2D())
    # model.add(Dense(1024, activation='relu'))
    # model.add(Dropout(0.5))
    # model.add(Dense(512, activation='relu'))
    # model.add(Dropout(0.5))
    # model.add(Dense(256, activation='relu'))
    # model.add(Dense(128, activation='relu'))
    # model.add(Dense(num_classes))

    return model

    
def build_discriminator_supervised(discriminator_base):          
    model = Sequential()
    model.add(discriminator_base)
    # Softmax activation, giving predicted probability distribution over the real classes
    model.add(Activation('softmax'))
    return model


def build_discriminator_unsupervised(discriminator_base):        
    model = Sequential()
    model.add(discriminator_base)
   
    def predict(x):
        # Transform distribution over real classes into a binary real-vs-fake probability
        prediction = 1.0 - (1.0 /
                            (K.sum(K.exp(x), axis=-1, keepdims=True) + 1.0))
        return prediction
    
    model.add(Lambda(predict))
    return model


#############################################################
#-----------------------Train&Test---------------------------
#############################################################

# import keras_metrics as km
from tensorflow.keras.metrics import Recall, Precision

def build_and_train_models(batch_size = batch_size):
  
    #* PARAMETERS CONFIGURATION--network parameters
    # the latent or z vector is 100-dim
    latent_size = 100     # 600
    train_steps = 10000   # 40000
    lr = 2e-4
    decay = 6e-8
    input_shape = (image_size, image_size, 1)

    # build discriminator model
    input = Input(shape=input_shape, name='discriminator_input_3channels')  #* for ResNet152V2
    inputs = concatenate([input, input, input])                             #* for ResNet152V2
    # inputs = Input(shape=input_shape, name='discriminator_input')         #* TODO for
    discriminator_base = build_discriminator_base(inputs)
    # [1] or original paper uses Adam, 
    # but discriminator converges easily with RMSprop
    optimizer = RMSprop(learning_rate=lr, decay=decay)

    # Build & compile the Discriminator for supervised training
    discriminator_supervised = build_discriminator_supervised(discriminator_base)
    discriminator_supervised.compile(loss='categorical_crossentropy',
                                 metrics=['accuracy', Precision(), Recall()],  #* 
                                 optimizer=optimizer)  
    discriminator_supervised.summary()

    # Build & compile the Discriminator for unsupervised training
    discriminator_unsupervised = build_discriminator_unsupervised(discriminator_base)
    discriminator_unsupervised.compile(loss='binary_crossentropy',
                                 metrics=['accuracy', Precision(), Recall()],  #* 
                                 optimizer=optimizer)                         
    discriminator_unsupervised.summary()

    # build generator model
    input_shape = (latent_size, )
    inputs = Input(shape=input_shape, name='z_input')
    generator = build_generator(inputs, image_size)
    generator.summary()

    # build adversarial model
    optimizer = RMSprop(learning_rate=lr * 0.5, decay=decay * 0.5)
    # freeze the weights of discriminator during adversarial training
    discriminator_unsupervised.trainable = False
    # adversarial = generator + discriminator
    adversarial = Model(inputs, 
                        discriminator_unsupervised(generator(inputs)),
                        name=model_name)
    adversarial.compile(loss='binary_crossentropy',
                        optimizer=optimizer,     
                        metrics=['accuracy', Precision(), Recall()])   #* 
    adversarial.summary()

    # train discriminator and adversarial networks
    models = (generator, discriminator_supervised, discriminator_unsupervised, adversarial)
    params = (batch_size, latent_size, train_steps, model_name)
    train(models, params)


def train(models, params):                             
    """Train the Discriminator and Adversarial Networks

    Alternately train Discriminator (supervised & unsupervised)
     and Adversarial networks by batch.
    
    Arguments:
        models (list): Generator, Discriminator, Adversarial models
        [Option]x_train (tensor): Train images
        [Option]y_train (tensor): Train images' labels
        params (list) : Networks parameters

    """
    # the GAN component models
    generator, discriminator_supervised, discriminator_unsupervised, adversarial = models
    # network parameters
    batch_size, latent_size, train_steps, model_name = params
    # the generator image is saved every 500 steps
    save_interval = 100  #* 500

    # noise vector to see how the generator output evolves during training
    noise_input = np.random.uniform(-1.0, 1.0, size=[16, latent_size]) 
    
    # Labels for real images: all ones
    real = np.ones((batch_size, 1))
    # Labels for fake images: all zeros
    fake = np.zeros((batch_size, 1))
    
    acc_list = [0,]
    acc_avg = [0,]
    j = 0
    for i in range(train_steps): 
        # -------------------------
        #  Train the Discriminator
        # -------------------------
        # Get a random batch of labeled images and their labels    
        real_images_labeled, real_images_labels = next(labeled_generator)
        real_images_labeled = real_images_labeled.reshape(-1, image_size, image_size, 1)
        real_images_labels = real_images_labels.reshape(-1,1)
        real_images_labels = to_categorical(real_images_labels, num_classes=num_classes)
        # real_images_labeled.shape # (64, 28, 28, 1)
        # real_images_labels.shape  # (64, 2)

        # Get a random batch of unlabeled images
        real_images_unlabeled, _ = next(train_generator)
        real_images_unlabeled = real_images_unlabeled.reshape(-1, image_size, image_size, 1)
        # real_images_unlabeled.shape

        # generate fake images from noise using generator 
        # generate noise using uniform distribution
        noise = np.random.uniform(-1.0,
                                  1.0,
                                  size=[batch_size, latent_size])
        # generate fake images
        fake_images = generator.predict(noise)
        
        # train the discriminator_supervised on 1 batch of real labeled examples
        d_loss_supervised, acc, pre, rec = discriminator_supervised.train_on_batch(real_images_labeled, real_images_labels)  
        log_1 = "%d: [discriminator_supervised loss: %f, acc: %f, pre: %f, rec: %f]" % (i, d_loss_supervised, acc, pre, rec)
        # print(log_1)
        
        # Train the discriminator_unsupervised on 1 batch of real unlabeled examples
        d_loss_real, acc, pre, rec = discriminator_unsupervised.train_on_batch(real_images_unlabeled, real, class_weight={0:(samples_train_UP/samples_train_CP), 1:1})  #* , class_weight={0:(47608/8484), 1:1}
        # Train the discriminator_unsupervised on 1 batch of fake examples
        d_loss_fake, acc, pre, rec = discriminator_unsupervised.train_on_batch(fake_images, fake) #* 
        d_loss_unsupervised = 0.5 * np.add(d_loss_real, d_loss_fake)
        log_2 = "%d: [discriminator_unsupervised loss: %f, acc: %f, pre: %f, rec: %f]" % (i, d_loss_unsupervised, acc, pre, rec)
        # print(log_2)

        # -------------------------
        #  Train the GAN(Generator)
        # -------------------------
        # train the adversarial network for 1 batch
        # 1 batch of fake images with label=1.0
        # since the discriminator weights 
        # are frozen in adversarial network
        # only the generator is trained
        # generate noise using uniform distribution
        noise = np.random.uniform(-1.0,
                                  1.0, 
                                  size=[batch_size, latent_size])
        # label fake images as real or 1.0
        y = np.ones([batch_size, 1])
        # train the adversarial network 
        # note that unlike in discriminator training, 
        # we do not save the fake images in a variable
        # the fake images go to the discriminator input of the adversarial
        # for classification
        # log the loss and accuracy
        g_loss, acc, pre, rec = adversarial.train_on_batch(noise, y)        
        
        if (i + 1) % save_interval == 0:
            log = "%s %s [adversarial loss: %f, acc: %f, pre: %f, rec: %f]" % (log_1, log_2, g_loss, acc, pre, rec)
            print(log)
            # plot generator images on a periodic basis
            plot_images(generator,
                        noise_input=noise_input,
                        show=False,
                        step=(i + 1),
                        model_name=model_name)
            
            # Save the best model of validation 
            x_val, y_val = next(validation_generator)
            x_val = x_val.reshape(-1, image_size, image_size, 1)
            y_val = y_val.reshape(-1,1)
            y_val = to_categorical(y_val, num_classes=num_classes)
            _, acc, _, _ = discriminator_supervised.evaluate(x_val, y_val)
            acc_list.append(acc)
            print("Discriminator_supervised Validated Accuracy: %.3f%%" % (100 * acc))
            acc_avg.append(np.mean(acc_list))
            
            # Smooth the validation Accuracy ()
            if acc_avg[j+1] > max(acc_avg[:j+1]):
                generator.save(model_name + "_Gen" + ".h5")
                discriminator_supervised.save(model_name + "_Dis-Sup" + ".h5")
                discriminator_unsupervised.save(model_name + "_Dis-Unsup" + ".h5")
                print("***================================================================> Model Saved @ substep-",i) 
                print("***================================================================> Current & Max Average Accuracy:", acc_avg[j+1], max(acc_avg[:j+1]))   
            j += 1  
            

def plot_images(generator,
                noise_input,
                show=False,
                step=0,
                model_name="gan"):
    """Generate fake images and plot them

    For visualization purposes, generate fake images
    then plot them in a square grid

    Arguments:
        generator (Model): The Generator Model for 
            fake images generation
        noise_input (ndarray): Array of z-vectors
        show (bool): Whether to show plot or not
        step (int): Appended to filename of the save images
        model_name (string): Model name

    """
    os.makedirs(model_name, exist_ok=True)
    filename = os.path.join(model_name, "%05d.png" % step)
    images = generator.predict(noise_input)
    plt.figure(figsize=(2.2, 2.2))
    num_images = images.shape[0]
    image_size = images.shape[1]
    rows = int(math.sqrt(noise_input.shape[0]))
    for i in range(num_images):
        plt.subplot(rows, rows, i + 1)
        image = np.reshape(images[i], [image_size, image_size])
        plt.imshow(image, cmap='gray')
        plt.axis('off')
    plt.savefig(filename)
    if show:
        plt.show()
    else:
        plt.close('all')


### TRAINING
build_and_train_models(batch_size = batch_size)






# TODO: test.py
# -------------------------
#  Test the Discriminator
# -------------------------
# Note that the test data should not be augmented!

from sklearn.metrics import confusion_matrix, classification_report
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

test_datagen = ImageDataGenerator(rescale=1. / 255)
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    color_mode='grayscale', 
    batch_size=batch_size,
    class_mode='binary')

# Compute classification metrics on test set
test_steps = int((samples_test_CP+samples_test_UP)/batch_size) 
discriminator_supervised = load_model(model_name + "_Dis-Sup" + ".h5")
acc_total_sup = 0
pre_total_sup = 0
rec_total_sup = 0
f1_total_sup = 0
for i in range(test_steps):
    x_test, y_test = next(test_generator)
    x = x_test.reshape(-1, image_size, image_size, 1)
    y_pred = discriminator_supervised.predict(x)    
    y_pred = np.argmax(y_pred, axis=1)
    acc = accuracy_score(y_test, y_pred)
    pre = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    acc_total_sup += acc
    pre_total_sup += pre
    rec_total_sup += rec
    f1_total_sup += f1

print("Accuracy: %.3f%%" % (100 * acc_total_sup/test_steps))
print("Precision: %.3f%%" % (100 * pre_total_sup/test_steps))
print("Recall: %.3f%%" % (100 * rec_total_sup/test_steps))
print("F1-score: %.3f%%" % (100 * f1_total_sup/test_steps))


# -------------------------
#  Test the Generator
# -------------------------
def test_generator(generator, latent_size=100):
    noise_input = np.random.uniform(-1.0, 1.0, size=[16, latent_size])  #* latent_size=100
    plot_images(generator,
                noise_input=noise_input,
                show=True,
                model_name="test_outputs")

generator = load_model(model_name + "_Gen" + ".h5")
test_generator(generator)


