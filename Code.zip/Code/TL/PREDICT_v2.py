# -*- coding: utf-8 -*-
"""
Dataset: all (as not referred)
TrainedModel: self-defined by 'load_model'
Workflow: Predict
Environment: keras-tf-gpu.yml

@author: mikelu
"""

# import keras
# keras.__version__


import os

from keras.engine.saving import load_model
from keras.preprocessing.image import ImageDataGenerator

current_cwd = os.getcwd()

trained_model_dir = os.path.join(current_cwd, 'SavedModels/')

trained_model_name = 'SDNET2018_P-MobileNetV2_2.h5'

model = load_model(trained_model_dir + trained_model_name)

model.summary()


import time

predict_img_dir = os.path.join(current_cwd, 'PredictImgs')

# 1) predict unlabeled images sequentially
# NOTE: put all the images into 'predict_img_dir/0' filefolder (Arbitrary name is ok)
t0 = time.time()

predict_datagen = ImageDataGenerator(rescale=1./255)

predict_generator = predict_datagen.flow_from_directory(
        predict_img_dir,
        target_size=(224, 224),
        batch_size=1,
        shuffle=False,
        # class_mode='binary'
        )

predicts = model.predict(predict_generator)
# predicts = model.predict_classes(predict_generator)   # can also use model.predict
# predicts = model.predict(predict_generator, batch_size=1, steps=len(predict_generator), verbose=1)
# predict_generator.reset()
# predicts = model.predict_generator(predict_generator, steps=len(predict_generator), verbose=1)

t1 = time.time()

print('average test time cost for each image:', (t1-t0)/len(predicts))
print(predict_generator.filenames)  # filenames is correspond to predicts



# # 2) predict labeled images sequentially
# # NOTE: put crack or uncrack images seperately into 'predict_img_dir/1'('predict_img_dir/crack') and
# # 'predict_img_dir/0'('predict_img_dir/uncrack') filefolders
# t0 = time.time()
#
# predict_datagen = ImageDataGenerator(rescale=1./255)
#
# predict_generator = predict_datagen.flow_from_directory(
#         predict_img_dir,
#         target_size=(224, 224),
#         batch_size=1,
#         class_mode='binary',
#         shuffle=False)
#
# predicts = model.predict_classes(predict_generator)
#
# t1 = time.time()
#
# print('average test time cost for each image:', (t1-t0)/len(predicts))
# print(predict_generator.filenames)  # filenames is correspond to predicts