# -*- coding: utf-8 -*-
"""
Dataset: SDNET2018, uneven
PretrainedModel: InceptionResnet-v2
Workflow: Train-validation-test

@author: mikelu
"""

import keras
# keras.__version__

### Build Dataset

import shutil, os


current_cwd = os.getcwd()

# for both windows OS and Linux OS
original_dataset_dir_CP = os.path.join(current_cwd, 'Datasets/SDNET2018_original/CP')
original_dataset_dir_UP = os.path.join(current_cwd, 'Datasets/SDNET2018_original/UP')

base_dir = os.path.join(current_cwd, 'Datasets/SDNET2018_uneven2')
os.mkdir(base_dir)

# Directories for training, validation and test splits
train_dir = os.path.join(base_dir, 'train')
os.mkdir(train_dir)

validation_dir = os.path.join(base_dir, 'validation')
os.mkdir(validation_dir)

test_dir = os.path.join(base_dir, 'test')
os.mkdir(test_dir)

# Directory with training crack images
train_crack_dir = os.path.join(train_dir, 'crack')
os.mkdir(train_crack_dir)

# Directory with training uncrack images
train_uncrack_dir = os.path.join(train_dir, 'uncrack')
os.mkdir(train_uncrack_dir)

# Directory with validation crack images
validation_crack_dir = os.path.join(validation_dir, 'crack')
os.mkdir(validation_crack_dir)

# Directory with validation uncrack images
validation_uncrack_dir = os.path.join(validation_dir, 'uncrack')
os.mkdir(validation_uncrack_dir)

# Directory with test crack images
test_crack_dir = os.path.join(test_dir, 'crack')
os.mkdir(test_crack_dir)

# Directory with test uncrack images
test_uncrack_dir = os.path.join(test_dir, 'uncrack')
os.mkdir(test_uncrack_dir)

import random

# train: validation : test = 7:1:2
samples_total_CP = int(8484 * 0.01 * 100)  
samples_train_CP = int(samples_total_CP * 0.7)
samples_val_CP = int(samples_total_CP * 0.1)
samples_test_CP = int(samples_total_CP * 0.2)

samples_total_UP = int(47608 * 0.01 * 100)  
samples_train_UP = int(samples_total_UP * 0.7)
samples_val_UP = int(samples_total_UP * 0.1)
samples_test_UP = int(samples_total_UP * 0.2)
batch_size = 32

# Copy crack images to train_crack_dir, validation_crack_dir, test_crack_dir
fnames = os.listdir(original_dataset_dir_CP)
random.shuffle(fnames)

for fname in fnames[:samples_train_CP]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(train_crack_dir, fname)
    shutil.copyfile(src, dst)

for fname in fnames[samples_train_CP:(samples_train_CP + samples_val_CP)]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(validation_crack_dir, fname)
    shutil.copyfile(src, dst)

for fname in fnames[(samples_train_CP + samples_val_CP):samples_total_CP]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(test_crack_dir, fname)
    shutil.copyfile(src, dst)

# Copy uncrack images to train_uncrack_dir, validation_uncrack_dir, test_uncrack_dir
fnames = os.listdir(original_dataset_dir_UP)
random.shuffle(fnames)

for fname in fnames[:samples_train_UP]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(train_uncrack_dir, fname)
    shutil.copyfile(src, dst)

for fname in fnames[samples_train_UP:(samples_train_UP + samples_val_UP)]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(validation_uncrack_dir, fname)
    shutil.copyfile(src, dst)

for fname in fnames[(samples_train_UP + samples_val_UP):samples_total_UP]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(test_uncrack_dir, fname)
    shutil.copyfile(src, dst)

### Import pre-trained model

from keras.applications import InceptionResNetV2

# weights_path_Inception = os.path.join(current_cwd, 'PretrainedWeights/resnet152v2_weights_tf_dim_ordering_tf_kernels_notop.h5')
#                         # mobilenet_1_0_224_tf_no_top.h5   inception_v3_weights_tf_dim_ordering_tf_kernels_notop.h5
conv_base = InceptionResNetV2(weights='imagenet',  # weights_path_Inception,
                      include_top=False,
                      input_shape=None,
                      input_tensor=None,
                      pooling=None,
                      classes=1000)

conv_base.summary()

# ==============================================================================
# Fine-tuning steps:
# * 1) Add your custom network on top of an already trained base network.
# * 2) Freeze the base network.
# * 3) Train the part you added.
# * 4) Unfreeze some layers in the base network.
# * 5) Jointly train both these layers and the part you added.
# ==============================================================================

# ------------------------------------------------------------------------------
# * 1) Add our own network on top of the pre-trained base network.
# ------------------------------------------------------------------------------

from keras import models, Model
from keras import optimizers
from keras.layers import GlobalAveragePooling2D, Dense, Dropout

# model = models.Sequential()
# model.add(conv_base)
# model.add(GlobalAveragePooling2D())
# model.add(Dense(1024, activation='relu'))
# model.add(Dropout(0.5))
# model.add(Dense(512, activation='relu'))
# model.add(Dropout(0.5))
# model.add(Dense(1, activation='sigmoid'))

model = models.Sequential()
model.add(conv_base)
model.add(GlobalAveragePooling2D())
model.add(Dense(1024, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(1024, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(256, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(128, activation='relu'))
model.add(Dense(1, activation='sigmoid'))

model.summary()

# ------------------------------------------------------------------------------
# * 2) Freeze the base network.
# ------------------------------------------------------------------------------
print('This is the number of trainable weights '
      'before freezing the conv base:', len(model.trainable_weights))

conv_base.trainable = False

print('This is the number of trainable weights '
      'after freezing the conv base:', len(model.trainable_weights))

# ------------------------------------------------------------------------------
# * 3) Train the part we added.
# ------------------------------------------------------------------------------
# Data augmentation
from keras.preprocessing.image import ImageDataGenerator
from keras.callbacks import EarlyStopping, ReduceLROnPlateau
import keras_metrics as km

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest')

# Note that the validation data should not be augmented!
test_datagen = ImageDataGenerator(rescale=1. / 255)

input_size_dim_1 = 229  # 224 or 256
input_size_dim_2 = 229

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    batch_size=batch_size,
    # Since we use binary_crossentropy loss, we need binary labels
    class_mode='binary')

validation_generator = test_datagen.flow_from_directory(
    validation_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    batch_size=batch_size,
    class_mode='binary')

model.compile(loss='binary_crossentropy',
              optimizer=optimizers.RMSprop(lr=2e-5),
              metrics=['acc', km.binary_precision(), km.binary_recall()])

model.summary()

# early_stopping = EarlyStopping(monitor='val_loss', patience=10, verbose=2, mode='auto')
# reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2,
#                               patience=5, min_lr=1e-6)
# callback_dic = [early_stopping, reduce_lr]

history = model.fit_generator(
    train_generator,
    steps_per_epoch=(samples_train_CP + samples_train_UP) // batch_size,
    epochs=30,  # 30
    validation_data=validation_generator,
    validation_steps=(samples_val_CP + samples_val_UP) // batch_size,
    class_weight='auto',
    # callbacks=callback_dic,
    verbose=2)

model.save(os.path.join(current_cwd, 'SavedModels/SDNET2018-InceptionResnetV2_1.h5'))

import matplotlib.pyplot as plt

acc = history.history['acc']
val_acc = history.history['val_acc']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(len(acc))

plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.legend()

plt.figure()

plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.legend()

plt.show()

# ------------------------------------------------------------------------------
# * 4) Unfreeze some layers in the base network.
# ------------------------------------------------------------------------------
conv_base.trainable = True

set_trainable = False
for layer in conv_base.layers:
    if layer.name == 'block8_1_conv':  # TODO since block8_1_conv to  block8_10_conv
        # need to modify for different datasets/models or unfreeze different layers
        set_trainable = True
    if set_trainable:
        layer.trainable = True
    else:
        layer.trainable = False

model.compile(loss='binary_crossentropy',
              optimizer=optimizers.RMSprop(lr=1e-5),
              metrics=['acc', km.binary_precision(), km.binary_recall()])

model.summary()

# ------------------------------------------------------------------------------
# * 5) Jointly train both these layers and the part we added.
# ------------------------------------------------------------------------------
history = model.fit_generator(
    train_generator,
    steps_per_epoch=(samples_train_CP + samples_train_UP) // batch_size,
    epochs=36,  # 100
    validation_data=validation_generator,
    validation_steps=(samples_val_CP + samples_val_UP) // batch_size,
    class_weight='auto',
    # callbacks=callback_dic,
    verbose=2)

model.save(os.path.join(current_cwd, 'SavedModels/SDNET2018-InceptionResnetV2_2.h5'))

acc = history.history['acc']
val_acc = history.history['val_acc']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(len(acc))

plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.legend()

plt.figure()

plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.legend()

plt.show()


# These curves look very noisy. To make them more readable, we can smooth them
# by replacing every loss and accuracy with exponential moving averages of these quantities.
def smooth_curve(points, factor=0.8):
    smoothed_points = []
    for point in points:
        if smoothed_points:
            previous = smoothed_points[-1]
            smoothed_points.append(previous * factor + point * (1 - factor))
        else:
            smoothed_points.append(point)
    return smoothed_points


plt.plot(epochs,
         smooth_curve(acc), 'bo', label='Smoothed training acc')
plt.plot(epochs,
         smooth_curve(val_acc), 'b', label='Smoothed validation acc')
plt.title('Training and validation accuracy')
plt.legend()

plt.figure()

plt.plot(epochs,
         smooth_curve(loss), 'bo', label='Smoothed training loss')
plt.plot(epochs,
         smooth_curve(val_loss), 'b', label='Smoothed validation loss')
plt.title('Training and validation loss')
plt.legend()

plt.show()

# TEST

import time
import numpy as np

acc_total = []
pre_total = []
rec_total = []

for i in range(10):
    t0 = time.time()

    test_generator = test_datagen.flow_from_directory(
        test_dir,
        target_size=(input_size_dim_1, input_size_dim_2),
        batch_size=batch_size,
        class_mode='binary')

    test_loss, test_acc, test_precision, test_recall = model.evaluate_generator(test_generator,
                                                   steps=(samples_test_CP + samples_test_UP) // batch_size)
    
    t1 = time.time()

    print('test acc:', test_acc)
    print('test precision:', test_precision)
    print('test recall:', test_recall)     
    print('test f1:', 2*test_precision*test_recall / (test_precision + test_recall))  

    print('average test time cost for each image:', (t1 - t0) / (samples_test_CP + samples_test_UP))

    acc_total.append(test_acc)
    pre_total.append(test_precision)
    rec_total.append(test_recall)

print("Test Average Accuracy: %.3f%%" % (100*np.mean(acc_total)))
print("Test Average Precision: %.3f%%" % (100*np.mean(pre_total)))
print("Test Average Recall: %.3f%%" % (100*np.mean(rec_total)))
print("Test Average F1-Score: %.3f%%" % (100*2*np.mean(pre_total)*np.mean(rec_total) / (np.mean(pre_total)+np.mean(rec_total))))

