# -*- coding: utf-8 -*-
"""
Dataset: SDNET2018, uneven/equal
PretrainedModel: MobileNet-v2
Workflow: Train-validation-test

Generate fine-tuned .h5 model loaded in SSGAN-TL

@author: mikelu-shanghai
"""

### Build Dataset

import shutil, os
import matplotlib.pyplot as plt

current_cwd = os.getcwd()
batch_size = 256 #*
num_classes = 2
image_size = 224    #* 32-256(224)

# for both windows OS and Linux OS
original_dataset_dir_CP = os.path.join(current_cwd, 'Datasets/SDNET2018_original/CP')
original_dataset_dir_UP = os.path.join(current_cwd, 'Datasets/SDNET2018_original/UP')

base_dir = os.path.join(current_cwd, 'Datasets/SDNET2018_uneven')
os.mkdir(base_dir)

# Directories for training, validation and test splits
train_dir = os.path.join(base_dir, 'train')
os.mkdir(train_dir)

validation_dir = os.path.join(base_dir, 'validation')
os.mkdir(validation_dir)

test_dir = os.path.join(base_dir, 'test')
os.mkdir(test_dir)

# Directory with training crack images
train_crack_dir = os.path.join(train_dir, 'crack')
os.mkdir(train_crack_dir)

# Directory with training uncrack images
train_uncrack_dir = os.path.join(train_dir, 'uncrack')
os.mkdir(train_uncrack_dir)

# Directory with validation crack images
validation_crack_dir = os.path.join(validation_dir, 'crack')
os.mkdir(validation_crack_dir)

# Directory with validation uncrack images
validation_uncrack_dir = os.path.join(validation_dir, 'uncrack')
os.mkdir(validation_uncrack_dir)

# Directory with test crack images
test_crack_dir = os.path.join(test_dir, 'crack')
os.mkdir(test_crack_dir)

# Directory with test uncrack images
test_uncrack_dir = os.path.join(test_dir, 'uncrack')
os.mkdir(test_uncrack_dir)

import random
import cv2

# train: validation : test = 7:1:2
samples_total_CP = int(8484 * 0.01 * 20)  # total 8484 images
samples_train_CP = int(samples_total_CP * 0.7)
samples_val_CP = int(samples_total_CP * 0.1)
samples_test_CP = int(samples_total_CP * 0.2)

samples_total_UP = int(47608 * 0.01 * 20)  # total 47608 images
samples_train_UP = int(samples_total_UP * 0.7)
samples_val_UP = int(samples_total_UP * 0.1)
samples_test_UP = int(samples_total_UP * 0.2)

# Copy crack images to train_crack_dir, validation_crack_dir, test_crack_dir
fnames = os.listdir(original_dataset_dir_CP)
random.shuffle(fnames)

for fname in fnames[:samples_train_CP]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(train_crack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb

for fname in fnames[samples_train_CP:(samples_train_CP + samples_val_CP)]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(validation_crack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb

for fname in fnames[(samples_train_CP + samples_val_CP):samples_total_CP]:
    src = os.path.join(original_dataset_dir_CP, fname)
    dst = os.path.join(test_crack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb

# Copy uncrack images to train_uncrack_dir, validation_uncrack_dir, test_uncrack_dir
fnames = os.listdir(original_dataset_dir_UP)
random.shuffle(fnames)

for fname in fnames[:samples_train_UP]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(train_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb

for fname in fnames[samples_train_UP:(samples_train_UP + samples_val_UP)]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(validation_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb

for fname in fnames[(samples_train_UP + samples_val_UP):samples_total_UP]:
    src = os.path.join(original_dataset_dir_UP, fname)
    dst = os.path.join(test_uncrack_dir, fname)
    img = cv2.imread(src, 1)                           #* gray
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)   #* gray
    cv2.imwrite(dst, gray_img)                         #* gray
    # shutil.copyfile(src, dst)                        #* rgb


### Import pre-trained model

from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Input, concatenate
# ----------------------------------------
#  for fine-tuned model loaded in SSGAN-TL
# ----------------------------------------
input_shape = (image_size, image_size, 1)
input = Input(shape=input_shape, name='input_3channels')   
inputs = concatenate([input, input, input])                             #* 

# weights_path_MobileNet = os.path.join(current_cwd, 'PretrainedWeights/mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')
#                                                                     # mobilenet_1_0_224_tf_no_top.h5
conv_base = MobileNetV2(weights='imagenet',    #  weights_path_MobileNet,
                      include_top=False,
                      input_shape=None,
                      alpha=1.0,
                      input_tensor=inputs,   # None,
                      pooling=None,
                      classes=1000)

conv_base.summary()

# ==============================================================================
# Fine-tuning steps:
# * 1) Add your custom network on top of an already trained base network.
# * 2) Freeze the base network.
# * 3) Train the part you added.
# * 4) Unfreeze some layers in the base network.
# * 5) Jointly train both these layers and the part you added.
# ==============================================================================

# ------------------------------------------------------------------------------
# * 1) Add our own network on top of the pre-trained base network.
# ------------------------------------------------------------------------------

from tensorflow.keras import models
from tensorflow.keras.models import Model, load_model
from tensorflow.keras import optimizers
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout

# # for 33% data
# model = models.Sequential()
# model.add(conv_base)
# model.add(GlobalAveragePooling2D())
# model.add(Dense(1024, activation='relu'))
# model.add(Dropout(0.5))
# model.add(Dense(512, activation='relu'))
# model.add(Dropout(0.5))
# model.add(Dense(num_classes, activation='softmax'))

# for 100% data
model = models.Sequential()
model.add(conv_base)
model.add(GlobalAveragePooling2D())
model.add(Dense(1024, activation='relu'))
model.add(Dropout(0.25))
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.25))
# model.add(Dense(256, activation='relu'))
# model.add(Dropout(0.25))
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.25))
model.add(Dense(num_classes, activation='softmax'))

model.summary()

# ------------------------------------------------------------------------------
# * 2) Freeze the base network.
# ------------------------------------------------------------------------------
print('This is the number of trainable weights '
      'before freezing the conv base:', len(model.trainable_weights))

conv_base.trainable = False

print('This is the number of trainable weights '
      'after freezing the conv base:', len(model.trainable_weights))

# ------------------------------------------------------------------------------
# * 3) Train the part we added.
# ------------------------------------------------------------------------------
# Data augmentation
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical
import numpy as np
# import keras_metrics as km

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest')


# Note that the validation data should not be augmented!
val_datagen = ImageDataGenerator(rescale=1. / 255)

input_size_dim_1 = image_size
input_size_dim_2 = image_size

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    color_mode='grayscale', 
    batch_size=batch_size,
    # Since we use binary_crossentropy loss, we need binary labels
    class_mode='binary')

validation_generator = val_datagen.flow_from_directory(
    validation_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    batch_size=batch_size,
    color_mode='grayscale', 
    class_mode='binary')

model.compile(loss='categorical_crossentropy',
              optimizer=optimizers.RMSprop(learning_rate=2e-5),
              metrics=['acc'])  # , km.binary_precision(), km.binary_recall()

model.summary()


import copy
def getMaxNumIndex(num_list, topk=10):
    '''
    Obtain the top k largest (or smallest) number index in a list
    '''
    tmp_list=copy.deepcopy(num_list)
    tmp_list.sort()
    max_num_index=[num_list.index(one) for one in tmp_list[::-1][:topk]]
    min_num_index=[num_list.index(one) for one in tmp_list[:topk]]
    return max_num_index

def smooth_curve(points, factor=0.8):
    smoothed_points = []
    for point in points:
        if smoothed_points:
            previous = smoothed_points[-1]
            smoothed_points.append(previous * factor + point * (1 - factor))
        else:
            smoothed_points.append(point)
    return smoothed_points


train_steps = 6600 # 6600
save_interval = 10

acc_train = [0,]
acc_list = [0,]
acc_avg = [0,]
j = 0
for i in range(train_steps):
    x_train, y_train = next(train_generator)
    x_train = x_train.reshape(-1, image_size, image_size, 1)
    y_train = y_train.reshape(-1,1)
    y_train = to_categorical(y_train, num_classes=num_classes) 
    loss, acc = model.train_on_batch(x_train, y_train, class_weight={0:samples_train_UP/samples_train_CP, 1:1})
    log = "%d: [Training loss: %f, acc: %f]" % (i, loss, acc)
    acc_train.append(acc)
    
    if (i + 1) % save_interval == 0:
        print(log)
        x_val, y_val = next(validation_generator)
        x_val = x_val.reshape(-1, image_size, image_size, 1)
        y_val = y_val.reshape(-1,1)
        y_val = to_categorical(y_val, num_classes=num_classes)
        loss, acc = model.evaluate(x_val, y_val)
        acc_list.append(acc)
        acc_avg.append(np.mean(acc_list))

        #* FOR FINE-TUNING DEBUG, TODO delete later
        if i > 100 and (i + 1) % (save_interval*20) == 0:
            # print("Validated Accuracy: %.3f%%" % (100 * acc))
            # print("***================================================================> Max Validated Accuracy @ substep-", save_interval*np.argmax(acc_list), acc_list[np.argmax(acc_list)])
            topk_index = getMaxNumIndex(acc_list)
            print("***================================================================> TOP 10 Max Validated Accuracy @ substep-", [n*save_interval-1 for n in topk_index])
            Max_acc = []
            for k in topk_index:
                Max_acc.append(acc_list[k])
            print(Max_acc)

        # Smooth the validation Accuracy ()        
        if acc_avg[j+1] > max(acc_avg[:j+1]):
            model.save(os.path.join(current_cwd, 'SavedModels/SDNET2018-MobileNetV2_1.h5'))
            print("***================================================================> Model Saved @ substep-",i) 
            print("***================================================================> Current & Max Average Accuracy:", acc_avg[j+1], max(acc_avg[:j+1]))    
        j += 1  

epochs = range(len(acc_list)-1)
plt.plot(epochs, smooth_curve(acc_train[1: : save_interval]), 'bo', label='Training acc')
plt.plot(epochs, smooth_curve(acc_list[1:]), 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.legend()
plt.show()


# ------------------------------------------------------------------------------
# * 4) Unfreeze some layers in the base network.
# ------------------------------------------------------------------------------
conv_base.trainable = True

set_trainable = False
for layer in conv_base.layers:
    if layer.name == 'block_12_expand':  # since block_16_expand
        # need to modify for different datasets/models or unfreeze different layers
        set_trainable = True
    if set_trainable:
        layer.trainable = True
    else:
        layer.trainable = False

model.compile(loss='categorical_crossentropy',
              optimizer=optimizers.RMSprop(learning_rate=1e-5),
              metrics=['acc'])   # , km.binary_precision(), km.binary_recall()

model.summary()

# ------------------------------------------------------------------------------
# * 5) Jointly train both these layers and the part we added.
# ------------------------------------------------------------------------------
train_steps = 2000 # 6600
save_interval = 10

acc_train = [0,]
acc_list = [0,]
acc_avg = [0,]
j = 0
for i in range(train_steps):
    x_train, y_train = next(train_generator)
    x_train = x_train.reshape(-1, image_size, image_size, 1)
    y_train = y_train.reshape(-1,1)
    y_train = to_categorical(y_train, num_classes=num_classes) 
    loss, acc = model.train_on_batch(x_train, y_train, class_weight={0:samples_train_UP/samples_train_CP, 1:1})
    log = "%d: [Training loss: %f, acc: %f]" % (i, loss, acc)
    acc_train.append(acc)
    
    if (i + 1) % save_interval == 0:
        print(log)
        x_val, y_val = next(validation_generator)
        x_val = x_val.reshape(-1, image_size, image_size, 1)
        y_val = y_val.reshape(-1,1)
        y_val = to_categorical(y_val, num_classes=num_classes)
        loss, acc = model.evaluate(x_val, y_val)
        acc_list.append(acc)
        acc_avg.append(np.mean(acc_list))

        #* FOR FINE-TUNING DEBUG, TODO delete later
        if i > 100 and (i + 1) % (save_interval*20) == 0:
            # print("Validated Accuracy: %.3f%%" % (100 * acc))
            # print("***================================================================> Max Validated Accuracy @ substep-", save_interval*np.argmax(acc_list), acc_list[np.argmax(acc_list)])
            topk_index = getMaxNumIndex(acc_list)
            print("***================================================================> TOP 10 Max Validated Accuracy @ substep-", [n*save_interval-1 for n in topk_index])
            Max_acc = []
            for k in topk_index:
                Max_acc.append(acc_list[k])
            print(Max_acc)

        # Smooth the validation Accuracy ()
        if acc_avg[j+1] > max(acc_avg[:j+1]):
            model.save(os.path.join(current_cwd, 'SavedModels/SDNET2018-MobileNetV2_2.h5'))
            print("***================================================================> Model Saved @ substep-",i) 
            print("***================================================================> Current & Max Average Accuracy:", acc_avg[j+1], max(acc_avg[:j+1]))    
        j += 1  

epochs = range(len(acc_list)-1)
plt.plot(epochs, smooth_curve(acc_train[1: : save_interval]), 'bo', label='Training acc')
plt.plot(epochs, smooth_curve(acc_list[1:]), 'b', label='Validation acc')
plt.title('Training and validation accuracy(FINE-TUNED)')
plt.legend()
plt.show()

### TEST

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

model_dir = os.path.join(current_cwd, 'SavedModels/')
model_name = 'SDNET2018-MobileNetV2_2.h5'

test_datagen = ImageDataGenerator(rescale=1. / 255)
test_generator = test_datagen.flow_from_directory(
    test_dir,
    target_size=(input_size_dim_1, input_size_dim_2),
    color_mode='grayscale', 
    batch_size=batch_size,
    class_mode='binary')

# Compute classification metrics on test set
test_steps = int((samples_test_CP+samples_test_UP)/batch_size) 
model_test = load_model(model_dir + model_name)
acc_total = []
pre_total = []
rec_total = []
f1_total = []
for i in range(test_steps):
    x_test, y_test = next(test_generator)
    x = x_test.reshape(-1, image_size, image_size, 1)
    y_pred = model_test.predict(x)    
    y_pred = np.argmax(y_pred, axis=1)
    acc = accuracy_score(y_test, y_pred)
    pre = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    acc_total.append(acc)
    pre_total.append(pre)
    rec_total.append(rec)
    f1_total.append(f1)

print("Average Accuracy: %.3f%%,       Max. Accuracy: %.3f%% " % (100*np.mean(acc_total), 100*np.max(acc_total)))
print("Average Precision: %.3f%%,      Max. Precision: %.3f%%" % (100*np.mean(pre_total), 100*np.max(pre_total)))
print("Average Recall: %.3f%%,         Max. Recall: %.3f%%" % (100*np.mean(rec_total), 100*np.max(rec_total)))
print("Average F1-score: %.3f%%,       Max. F1-score: %.3f%%" % (100*np.mean(f1_total), 100*np.max(f1_total)))

# # Compute classification metrics on test set
# test_steps = int((samples_test_CP+samples_test_UP)/batch_size) 
# model_test = load_model(model_dir + model_name)
# acc_total = 0
# pre_total = 0
# rec_total = 0
# f1_total = 0
# for i in range(test_steps):
#     x_test, y_test = next(test_generator)
#     x = x_test.reshape(-1, image_size, image_size, 1)
#     y_pred = model_test.predict(x)    
#     y_pred = np.argmax(y_pred, axis=1)
#     acc = accuracy_score(y_test, y_pred)
#     pre = precision_score(y_test, y_pred)
#     rec = recall_score(y_test, y_pred)
#     f1 = f1_score(y_test, y_pred)
#     acc_total += acc
#     pre_total += pre
#     rec_total += rec
#     f1_total += f1

# print("Accuracy: %.3f%%" % (100 * acc_total/test_steps))
# print("Precision: %.3f%%" % (100 * pre_total/test_steps))
# print("Recall: %.3f%%" % (100 * rec_total/test_steps))
# print("F1-score: %.3f%%" % (100 * f1_total/test_steps))

